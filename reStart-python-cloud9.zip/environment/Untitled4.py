
for i in range (2,250):
    count=0;

    for j in range (2,i-1):
        if (i%j ==0):
            count=count+1
    if count==0:
            print(i)
        